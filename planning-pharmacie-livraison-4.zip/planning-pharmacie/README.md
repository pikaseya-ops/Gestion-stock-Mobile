# Planning Pharmacie — Application bureau multi-postes

> Application desktop Windows / macOS pour officine de pharmacie :
> planning d'équipe avec génération automatique, gestion des tâches Kanban,
> et transmissions équipe. Multi-postes, données 100 % en local.

## État du développement

| Étape | Contenu | État |
|-------|---------|------|
| 1     | Backend planning | ✅ |
| 2     | Backend tâches + transmissions + comptes individuels | ✅ |
| 3     | Front-end planning + login + comptes | ✅ |
| 4     | **Front-end module Tâches (Kanban + drag & drop)** | ✅ **Cette livraison** |
| 5     | Front-end module Transmissions | À venir |
| 6     | Wrapper Electron + GitHub Actions + installateurs Win/Mac | À venir |

## 🎉 Nouveautés de la livraison 4

### Module Tâches complet — inspiré Bakofi

Un vrai système de tableaux Kanban, avec :

- **Écran principal** avec 3 vues rapides en haut (Mes tâches, Aujourd'hui, En retard)
- **Tableaux illimités** organisés par thématique (routine, commandes, formations, AQ…)
- **Drag & drop** natif des cartes entre colonnes (via @dnd-kit)
- **Cartes riches** : titre, description, priorité (normale/haute/urgente), échéance, étiquettes, assignations multiples, checklist, commentaires
- **Auto-completion** : dès qu'une carte arrive dans une colonne "Terminé", elle est marquée comme complétée automatiquement
- **Filtrage** : afficher/masquer les tâches terminées

### 8 modèles préfaits officine prêts à l'emploi

Au moment de créer un tableau, choix parmi :

1. **Routine officinale** — Ouverture, fermeture, contrôle frigo, dates de péremption, ménage (avec checklists préremplies : fond de caisse, température, alarme...)
2. **Commandes labos** — 5 colonnes : À préparer / Envoyée / En attente / Reçue / Litige
3. **Formations équipe** — Suivi DPC, e-learning, journées labo
4. **AQ / Anomalies** — Signalement, analyse cause racine, action corrective, suivi
5. **Challenges labos** — Objectifs commerciaux
6. **Promo & Merch** — Opérations vitrines saisonnières
7. **Tâches prioritaires** — Urgences transverses
8. **Tableau vierge** — 3 colonnes simples pour démarrer de zéro

Le modèle "Routine officinale" préremplit par exemple une tâche "Ouverture officine" avec la checklist : allumer enseigne, démarrer postes, vérifier caisses, relever températures frigo, consulter mails/fax, vérifier commandes du jour.

### Permissions par rôle

| Action | Membre | Admin |
|--------|--------|-------|
| Voir les tableaux, les tâches | ✅ | ✅ |
| Créer/modifier une tâche, cocher checklist | ✅ | ✅ |
| Déplacer une tâche (drag & drop) | ✅ | ✅ |
| Supprimer sa propre tâche | ✅ | ✅ |
| Supprimer n'importe quelle tâche | ❌ | ✅ |
| Créer/supprimer/archiver un tableau | ❌ | ✅ |
| Ajouter/supprimer une colonne | ❌ | ✅ |

## Comment tester en local

### Prérequis
- Node.js 18+ ([téléchargement officiel](https://nodejs.org/))

### Installation
```bash
cd planning-pharmacie
npm install
```

### Démarrage (2 terminaux)

**Terminal 1 — Serveur** :
```bash
npm run server
```

**Terminal 2 — Front-end** :
```bash
npm run client:dev
```

Ouvre **http://localhost:5173**.

Au premier démarrage : écran de bienvenue qui te demande de créer le compte titulaire. Ensuite, tu peux :
1. Ajouter tes employés dans **Personnel**
2. Créer des comptes pour ton équipe dans **Comptes** (tu peux lier chaque compte à un employé)
3. Dans **Tâches**, cliquer **Nouveau tableau** et choisir le modèle "Routine officinale" pour voir les checklists préremplies

## Architecture logicielle

```
Backend (Node.js + Express + SQLite)
└── server/
    ├── index.js, db.js, backup.js
    └── routes/
        ├── auth.js         + nouvel endpoint GET /api/auth/team
        ├── tasks.js        + nouvel endpoint GET /api/tasks/boards/:bid/columns-list
        └── ... (autres inchangés)

Front-end (React + Vite + Tailwind + @dnd-kit)
└── client/src/
    ├── App.jsx             Orchestration (+ entrée "Tâches" dans sidebar)
    ├── api.js              Client API (+ listTeam)
    ├── auth.jsx, ui.jsx, constants.js, utils.js, planning-algorithm.js
    ├── LoginScreen.jsx, UsersScreen.jsx
    ├── screens.jsx         Écrans du planning
    └── tasks/              (nouveau dossier)
        ├── TasksScreen.jsx    Écran principal (liste tableaux + vues rapides)
        ├── KanbanBoard.jsx    Board avec drag & drop
        ├── TaskFormModal.jsx  Création/édition d'une tâche
        ├── NewBoardModal.jsx  Sélecteur de modèle préfait
        └── theme.js           Helpers couleurs/icônes
```

## Endpoints backend utilisés par le module Tâches

### Boards
- `GET  /api/tasks/boards` — liste tableaux
- `GET  /api/tasks/boards/templates` — modèles préfaits
- `POST /api/tasks/boards/from-template` — créer depuis modèle
- `POST /api/tasks/boards` — créer tableau vierge
- `PUT/DELETE /api/tasks/boards/:id` — édition/suppression
- `POST /api/tasks/boards/:id/archive` — archivage

### Columns
- `GET  /api/tasks/boards/:bid/columns-list` — liste colonnes
- `POST /api/tasks/boards/:bid/columns` — créer
- `PUT/DELETE /api/tasks/columns/:id` — édition/suppression
- `POST /api/tasks/columns/reorder` — réordonner

### Tasks
- `GET  /api/tasks/boards/:bid/tasks` — liste (avec assignees + checklist enrichis)
- `POST /api/tasks/boards/:bid/tasks` — créer
- `PUT  /api/tasks/tasks/:id` — modifier
- `POST /api/tasks/tasks/:id/move` — drag & drop (change column + sortOrder)
- `POST /api/tasks/tasks/:id/complete|uncomplete`
- `DELETE /api/tasks/tasks/:id`

### Checklist
- `POST /api/tasks/tasks/:id/checklist` — ajouter item
- `PUT/DELETE /api/tasks/checklist/:id`

### Vues spéciales
- `GET /api/tasks/my` — mes tâches assignées
- `GET /api/tasks/today` — échéance aujourd'hui
- `GET /api/tasks/overdue` — en retard

## Prochaines étapes

**Livraison 5** : écran Transmissions (notes équipe avec accusés de lecture)
**Livraison 6** : Electron + GitHub Actions + installateurs signés

## Dépannage

Voir section "Dépannage" des livraisons précédentes. Nouveaux points :

**Drag & drop qui ne réagit pas** : vérifier que `@dnd-kit/core` est bien installé (`npm ls @dnd-kit/core`).

**Erreur "listColumns 404"** : redémarrer le serveur (la nouvelle route `/columns-list` nécessite un reload).

**Base de données déjà existante** : la migration `v2` crée automatiquement les tables Tâches si tu mets à jour depuis la livraison 1 — aucune action à faire.
