# Planning Pharmacie — Application bureau multi-postes

> Application desktop Windows / macOS pour officine de pharmacie :
> planning d'équipe avec génération automatique, gestion des tâches Kanban,
> et transmissions équipe. Multi-postes, données 100 % en local.

## État du développement

| Étape | Contenu | État |
|-------|---------|------|
| 1     | Backend planning (staff, congés, plannings, sauvegardes) | ✅ |
| 2     | Backend tâches + transmissions + comptes individuels | ✅ **Cette livraison** |
| 3     | Front-end planning (login + appels API) | À venir |
| 4     | Front-end module Tâches (Kanban) | À venir |
| 5     | Front-end module Transmissions | À venir |
| 6     | Wrapper Electron + GitHub Actions + installateurs Win/Mac | À venir |

## Modules backend disponibles

### 🗓️ Planning (livraison 1)
Génération automatique du planning hebdomadaire avec contraintes (rôles,
heures cibles, OFF fixes/variables, rotation samedi, incompatibilités, etc.),
gestion congés avec compteur CP, minima par tranche de 30 min.

### ✅ Tâches Kanban (livraison 2 — nouveau)
Tableaux de tâches façon Trello : tableaux personnalisables avec colonnes,
cartes assignables à plusieurs membres, checklists, étiquettes, priorités,
échéances. Vues "Mes tâches", "Aujourd'hui", "En retard".

**8 modèles préfaits inspirés Bakofi** :
- Routine officinale (ouverture, fermeture, frigos, contrôles)
- Commandes labos (à préparer / envoyée / en attente / reçue / litige)
- Formations équipe (DPC, e-learning, journées labo)
- AQ / Anomalies (signalement, analyse, action, résolu)
- Challenges labos
- Promo & Merch
- Tâches prioritaires
- Tableau vierge (3 colonnes simples)

### 💬 Transmissions équipe (livraison 2 — nouveau)
Notes équipe avec **accusés de lecture** : qui a vu quoi et quand.
Épinglage (admin), catégories, recherche plein texte, marquage important
(accusé de lecture obligatoire), commentaires.

### 👥 Comptes individuels (livraison 2 — nouveau)
Système d'authentification multi-comptes :
- 1 compte titulaire (rôle `admin`) créé à l'installation
- N comptes membres (rôle `member`) créés depuis l'admin
- Chaque membre peut être lié à un employé du planning (`staffId`)
- Mot de passe individuel + réinitialisation par l'admin

**Permissions** :
| Action | Member | Admin |
|--------|--------|-------|
| Voir le planning | ✅ | ✅ |
| Modifier planning, contraintes, congés | ❌ | ✅ |
| Voir les tableaux de tâches | ✅ | ✅ |
| Créer/modifier tâches | ✅ | ✅ |
| Créer/supprimer un tableau | ❌ | ✅ |
| Lire les transmissions | ✅ | ✅ |
| Écrire/commenter | ✅ | ✅ |
| Épingler une transmission | ❌ | ✅ |
| Gérer les comptes utilisateurs | ❌ | ✅ |
| Sauvegardes manuelles, import/export | ❌ | ✅ |

## Architecture (cible)

```
Pharmacie — réseau Wi-Fi/Ethernet
│
├── PC serveur (n'importe lequel, allumé pendant les heures d'ouverture)
│   └── Planning Pharmacie.exe / .app
│       ├── Serveur Express (port 3017) → API REST + serveur de fichiers
│       ├── Base SQLite locale → toutes les données
│       ├── Sauvegardes auto quotidiennes (30 jours conservés)
│       └── Icône système tray
│
└── Postes clients (chaque employé sur son poste / tablette)
    └── Navigateur → http://[ip-serveur]:3017
        └── Login individuel (identifiant + mot de passe)
            ├── Mode admin → tout faire
            └── Mode member → consulter, cocher tâches, lire/écrire transmissions
```

## Endpoints du backend

### Authentification
- `GET  /api/auth/status` — état (setup requis ? loggé ? rôle ?)
- `POST /api/auth/setup` — création du 1er compte admin
- `POST /api/auth/login` — se connecter
- `POST /api/auth/logout` — se déconnecter
- `POST /api/auth/password` — changer son mot de passe

### Gestion des comptes (admin only)
- `GET    /api/auth/users` — liste des comptes
- `POST   /api/auth/users` — créer un compte
- `PUT    /api/auth/users/:id` — modifier
- `DELETE /api/auth/users/:id` — supprimer
- `POST   /api/auth/users/:id/reset-password` — réinitialiser mot de passe

### Données planning (lecture libre, écriture admin)
- `/api/staff`, `/api/leaves`, `/api/settings`, `/api/coverage`, `/api/plannings`

### Tâches Kanban
- `GET  /api/tasks/boards` — liste tableaux
- `POST /api/tasks/boards` — créer tableau (admin)
- `POST /api/tasks/boards/from-template` — créer depuis modèle (admin)
- `GET  /api/tasks/boards/templates` — liste modèles disponibles
- `POST /api/tasks/boards/:id/archive` — archiver/désarchiver (admin)
- `POST /api/tasks/boards/:bid/columns` — créer colonne (admin)
- `PUT  /api/tasks/columns/:id` — modifier colonne (admin)
- `GET  /api/tasks/boards/:bid/tasks` — liste tâches d'un tableau
- `POST /api/tasks/boards/:bid/tasks` — créer tâche
- `PUT  /api/tasks/tasks/:id` — modifier tâche
- `POST /api/tasks/tasks/:id/move` — drag & drop (changer colonne/ordre)
- `POST /api/tasks/tasks/:id/complete` — marquer terminée
- `POST /api/tasks/tasks/:id/checklist` — ajouter item checklist
- `GET  /api/tasks/my` — mes tâches assignées
- `GET  /api/tasks/today` — tâches d'aujourd'hui
- `GET  /api/tasks/overdue` — tâches en retard

### Transmissions
- `GET  /api/transmissions` — liste (filtres : `?unread=1`, `?pinned=1`, `?category=`, `?q=`)
- `GET  /api/transmissions/:id` — détail (avec lecteurs et non-lecteurs)
- `POST /api/transmissions` — créer
- `PUT  /api/transmissions/:id` — modifier (auteur ou admin)
- `POST /api/transmissions/:id/pin` — épingler (admin)
- `POST /api/transmissions/:id/read` — marquer comme lu
- `POST /api/transmissions/:id/comments` — commenter
- `GET  /api/transmissions/unread-count` — compteur non-lus

### Sauvegarde
- `GET  /api/backup/list` — liste snapshots
- `POST /api/backup/now` — sauvegarde immédiate (admin)
- `GET  /api/backup/export` — export JSON portable
- `POST /api/backup/import` — import JSON (admin)

## Localisation des données

| OS | Chemin |
|----|--------|
| Windows | `%APPDATA%\Planning Pharmacie\` |
| macOS   | `~/Library/Application Support/Planning Pharmacie/` |
| Linux   | `~/.config/Planning Pharmacie/` |
| Dev     | `./data/` à la racine du projet |

## Schéma de la base SQLite

13 tables, organisées en 4 groupes :

**Système (3)** : `kv` (stockage planning), `accounts`, `audit_log`

**Tâches Kanban (7)** : `boards`, `board_columns`, `tasks`, `task_assignees`,
`task_checklist_items`, `task_comments`, `task_recurrences`

**Transmissions (3)** : `transmissions`, `transmission_reads`, `transmission_comments`

Migrations gérées via `PRAGMA user_version` (actuellement v2).

## Prochaine étape

Livraison 3 : adaptation du front-end React du planning existant pour utiliser
l'API au lieu de `localStorage`, écran de login, écran de gestion des comptes.

Puis livraisons 4-5-6 pour les écrans Tâches/Transmissions et l'empaquetage Electron.
