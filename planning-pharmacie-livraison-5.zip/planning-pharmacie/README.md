# Planning Pharmacie — Application bureau multi-postes

> Application desktop Windows / macOS pour officine de pharmacie :
> planning d'équipe avec génération automatique, gestion des tâches Kanban,
> et transmissions équipe. Multi-postes, données 100 % en local.

## État du développement

| Étape | Contenu | État |
|-------|---------|------|
| 1     | Backend planning | ✅ |
| 2     | Backend tâches + transmissions + comptes individuels | ✅ |
| 3     | Front-end planning + login + comptes | ✅ |
| 4     | Front-end module Tâches (Kanban + drag & drop) | ✅ |
| 5     | **Front-end module Transmissions + badge sidebar** | ✅ **Cette livraison** |
| 6     | Wrapper Electron + GitHub Actions + installateurs Win/Mac | À venir |

## 🎉 Nouveautés de la livraison 5

### Module Transmissions — notes équipe avec accusés de lecture

Un véritable système de transmissions pour centraliser les consignes, remplaçant les post-it et les messages WhatsApp :

- **Fil d'actualité** : toutes les transmissions dans une vue unique, triées par date (les épinglées en haut)
- **Titre optionnel** + **message riche** multiligne
- **Catégories libres** : "Frigos", "Caisses", "AQ", etc. — tu crées tes propres catégories au fur et à mesure
- **Marquage important** avec badge visible (accusé de lecture à surveiller)
- **Épinglage** par l'admin des messages à garder en tête
- **Accusés de lecture** : pour chaque transmission, tu vois **qui a lu et quand**, et surtout **qui n'a pas encore lu**
- **Commentaires** : discussion sous chaque transmission (threading simple)
- **Recherche plein texte** dans titres + contenu
- **Filtres rapides** : Non lues / Épinglées / Mes écrits

### Badge de notifications dans la sidebar

L'entrée "Transmissions" du menu de gauche affiche en permanence **le nombre de transmissions non lues** (par toi, spécifiquement), avec rafraîchissement automatique toutes les 30 secondes.

### Permissions par rôle

| Action | Membre | Admin |
|--------|--------|-------|
| Lire les transmissions | ✅ | ✅ |
| Créer une transmission | ✅ | ✅ |
| Modifier sa propre transmission | ✅ | ✅ |
| Modifier une transmission d'autrui | ❌ | ✅ |
| Supprimer sa propre transmission | ✅ | ✅ |
| Supprimer une transmission d'autrui | ❌ | ✅ |
| Commenter | ✅ | ✅ |
| Épingler / désépingler | ❌ | ✅ |
| Voir qui a lu / pas lu | ✅ | ✅ |

## Cas d'usage concrets

**Exemple 1 — Consigne urgente du matin** :
Titulaire publie "⚠️ Nouvelle procédure pour les commandes Cooper" avec le tag "Important". Elle voit en temps réel qui de l'équipe l'a déjà lue. À 10h, il reste 2 personnes qui n'ont pas encore lu → elle peut leur rappeler directement.

**Exemple 2 — Transmission de passage d'équipe** :
Pharmacien du matin laisse un message en fin de shift ("Monsieur Dupont doit repasser pour sa prescription, voir notes sur l'ordo"). L'équipe du soir a 1 notification, clique dessus, l'accusé de lecture est automatique.

**Exemple 3 — Question posée à l'équipe** :
Préparateur publie "Où est-ce qu'on range les dispositifs pour diabète ?" en catégorie "Stock". 2 collègues répondent en commentaires, ça reste consultable pour tout nouveau membre.

## Architecture logicielle (mise à jour)

```
Backend (Node.js + Express + SQLite)
└── server/
    ├── index.js, db.js, backup.js
    └── routes/
        ├── auth.js, tasks.js, transmissions.js, ... (inchangés depuis livraison 2)

Front-end (React + Vite + Tailwind + @dnd-kit)
└── client/src/
    ├── App.jsx              Orchestration (+ entrée "Transmissions" avec badge non-lus)
    ├── api.js               Client API
    ├── auth.jsx, ui.jsx, constants.js, utils.js, planning-algorithm.js
    ├── LoginScreen.jsx, UsersScreen.jsx
    ├── screens.jsx          Écrans du planning
    ├── tasks/               Module Tâches (livraison 4)
    │   ├── TasksScreen.jsx, KanbanBoard.jsx, TaskFormModal.jsx, NewBoardModal.jsx, theme.js
    └── transmissions/       Module Transmissions (nouveau)
        ├── TransmissionsScreen.jsx    Fil + filtres + recherche
        ├── TransmissionDetailModal.jsx Détail + accusés de lecture + commentaires
        └── TransmissionFormModal.jsx   Création/édition
```

## Endpoints backend utilisés

### Transmissions (tous existaient déjà depuis livraison 2)
- `GET /api/transmissions` — liste avec filtres `?unread=1`, `?pinned=1`, `?category=`, `?q=`
- `GET /api/transmissions/unread-count` — compteur non-lus
- `GET /api/transmissions/categories` — liste des catégories utilisées
- `GET /api/transmissions/:id` — détail (+ liste `readers` + liste `notRead`)
- `POST /api/transmissions` — créer (auteur automatiquement marqué comme lecteur)
- `PUT /api/transmissions/:id` — modifier (auteur ou admin)
- `POST /api/transmissions/:id/pin` — épingler (admin)
- `POST /api/transmissions/:id/read` — marquer comme lu (auto à l'ouverture détail)
- `DELETE /api/transmissions/:id` — supprimer (auteur ou admin)
- `GET /api/transmissions/:id/comments`
- `POST /api/transmissions/:id/comments`
- `DELETE /api/transmissions/comments/:cid`

## Comment tester en local

Prérequis inchangés (Node.js 18+).

```bash
cd planning-pharmacie
npm install    # prend 3-4 min
npm run server # terminal 1
npm run client:dev # terminal 2
```

Ouvre **http://localhost:5173**, va dans **Transmissions** et publie ta première note. Ouvre un second navigateur en mode privé (ou un autre appareil), connecte-toi avec un autre compte membre, ouvre la transmission → tu verras l'accusé de lecture apparaître en temps réel côté admin.

**Astuce pour tester** : crée 2 ou 3 comptes membres dans **Comptes**, ouvre `http://localhost:5173` dans plusieurs navigateurs, connecte-toi avec un compte différent dans chacun. Tu simules ton équipe.

## Prochaines étapes

**Livraison 6** (dernière) : wrapper Electron + GitHub Actions + installateurs signés Windows/Mac. Le projet deviendra un vrai `.exe` / `.dmg` que ton équipe installe en double-cliquant.
